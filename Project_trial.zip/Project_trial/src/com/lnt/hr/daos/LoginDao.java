package com.lnt.hr.daos;

import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;

public interface LoginDao 
{
	public Login insertNewStudent(Login login) throws LoginException;
	public int loginCheck(Login login) throws LoginException;
	//public Login loginCheck(Login login) throws LoginException;

}
