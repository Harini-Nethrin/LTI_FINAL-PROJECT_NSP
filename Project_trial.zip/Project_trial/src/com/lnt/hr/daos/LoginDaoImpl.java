package com.lnt.hr.daos;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.transaction.annotation.Propagation;
import org.hibernate.HibernateException;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.lnt.hr.entities.Login;
import com.lnt.hr.exception.LoginException;
import com.lnt.hr.exception.ScholarshipException;

@Repository
@Transactional(propagation= Propagation.REQUIRED)
public class LoginDaoImpl implements LoginDao
{
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public Login insertNewStudent(Login login) throws LoginException 
	{
		try
		{
			entityManager.persist(login);
			return login;
		}
		catch(Exception e)
		{
			throw new LoginException("OOP's!!! Something went wrong while inserting a new student", e);
		}
		
	}

	/*@Override
	public Login loginCheck(Login login) throws LoginException 
	{
		
		Query query=entityManager.createNamedQuery("from Login where loginId=:loginId and password=:password");
		query.setParameter("loginId", login.getLoginId());
		query.setParameter("password", login.getPassword());
		login=(Login) query.getSingleResult();
		return login;
	}*/
	
	

	@Override
	public int loginCheck(Login login) throws LoginException 
	{
		/*String sql = "from Login where loginId=:loginId and password= :password";
		Query query = entityManager.createQuery(sql, Login.class);*/
		Query query = entityManager.createQuery("select loginId from Login where loginId=:loginId and password= :password");
		query.setParameter("loginId", login.getLoginId());
		query.setParameter("password", login.getPassword());
		List<Integer> userDetailsList = query.getResultList();
		
		if(userDetailsList.size()>0)
		{
			return userDetailsList.get(0);
		}
		return -1;
	}
	
	
	
	

	

}
