package com.lnt.hr.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lnt.hr.daos.ScholarshipDao;
import com.lnt.hr.entities.Scholarship;
import com.lnt.hr.exception.RegistrationException;
import com.lnt.hr.exception.ScholarshipException;

@Service("ScholarshipServiceImpl")
public class ScholarshipServiceImpl implements ScholarshipService
{
	@Autowired
	private ScholarshipDao dao;

	@Override
	public List<Scholarship> getStudList() throws ScholarshipException 
	{	
		return dao.getStudList();
	}

	@Override
	public Scholarship getApplDetails(long applicationId) throws ScholarshipException 
	{
		return dao.getApplDetails(applicationId);
	}

	@Override
	public Scholarship setApplicationStatus(Scholarship scholarship) throws ScholarshipException {

		return dao.setApplicationStatus(scholarship);
	}

	@Override
	public Scholarship insertNewScholarship(Scholarship scholarship) throws ScholarshipException 
	{
		return dao.insertNewScholarship(scholarship);
	}

	@Override
	public List<Scholarship> getMinStudList() throws ScholarshipException 
	{
		return dao.getMinStudList();

	}



	/*@Override
	public ScholarshipDao updatScholarshipStatus(ScholarshipDao scholarshipStatus) 
	{
		return dao.setScholarshipStatus(scholarshipStatus);
	}*/




}
