package com.lnt.hr.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.lnt.hr.daos.RegistrationDao;
import com.lnt.hr.entities.Registration;
import com.lnt.hr.exception.RegistrationException;

@Service("RegistrationServiceImpl")
//@Component
public class RegistrationServiceImpl implements RegistrationService 
{
	@Autowired
	RegistrationDao regDao;

	@Override
	public Registration insertNewStudent(Registration registration) throws RegistrationException 
	{
		return regDao.insertNewStudent(registration);
	}

}
