package com.lnt.hr.exception;

public class ScholarshipException extends Exception 
{


	public ScholarshipException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	public ScholarshipException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

	
}
